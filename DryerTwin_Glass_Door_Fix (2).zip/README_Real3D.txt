Dryer Twin — Real 3D software

1. Extract this ZIP to a folder.
2. Open index.html in Chrome while connected to the internet (Three.js loads from a CDN).
3. On Dashboard, use Open Door / Close Door to animate the glass door. The door status changes between OPEN and CLOSED.
4. Drag the model to rotate, use the mouse wheel or +/- buttons to zoom, and use Reset View to reset.

The glass door is a translucent blue-tinted panel with a stainless frame. Temperature controls and the rest of the existing software are retained.

Note: This is a browser simulation. It does not operate physical dryer hardware or send real email OTPs.
